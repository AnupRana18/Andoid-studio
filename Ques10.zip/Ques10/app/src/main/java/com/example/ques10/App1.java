package com.example.ques10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class App1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app1);
    }
}