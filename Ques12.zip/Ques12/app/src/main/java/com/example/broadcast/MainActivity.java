package com.example.broadcast;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b=findViewById(R.id.setalarm);
        EditText e=(EditText) findViewById(R.id.time);
        AlarmManager alarmManager= (AlarmManager) getSystemService(ALARM_SERVICE);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int time= Integer.parseInt((e).getText().toString());
                long alarmtime = System.currentTimeMillis()+(time*1000);

                Intent i=new Intent(MainActivity.this, MyReceiver.class);
                PendingIntent pendingIntent= PendingIntent.getBroadcast(MainActivity.this,100,i,0);

                alarmManager.set(AlarmManager.RTC_WAKEUP,alarmtime,pendingIntent);
            }
        });
    }
}