package com.example.ques15;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyDBHelper dbHelper = new MyDBHelper(this);
        dbHelper.addContact("neha" , "7005023734");
        dbHelper.addContact("namita" , "123456789");
        dbHelper.addContact("ayush" , "7005023712");
        dbHelper.addContact("geeta" , "7001243734");
    }
}